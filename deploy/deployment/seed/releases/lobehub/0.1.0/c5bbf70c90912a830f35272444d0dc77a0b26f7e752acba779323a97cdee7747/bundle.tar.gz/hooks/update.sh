#!/usr/bin/env bash
# =============================================================================
# Hook: update — LobeHub (lobehub)
# 更新 = 幂等重装：install 会按 config 中最新的镜像 tag 重建/拉起容器。
# 由 Agent Runner 以固定参数调用；幂等可重跑。
# =============================================================================
set -euo pipefail
exec "$(dirname "$0")/install.sh" "$@"
